--
-- PostgreSQL database dump (dbbackup native engine)
-- Generated on: 2026-01-30T21:02:00+01:00
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

CREATE TABLE "public"."orders" (
    "id" integer NOT NULL DEFAULT nextval('orders_id_seq'::regclass),
    "product_id" integer,
    "quantity" integer NOT NULL,
    "order_date" timestamp DEFAULT now(),
    "customer_email" character varying(255),
    "status" character varying(20) DEFAULT 'pending'::character varying
);
CREATE TABLE "public"."products" (
    "id" integer NOT NULL DEFAULT nextval('products_id_seq'::regclass),
    "name" character varying(100) NOT NULL,
    "price" numeric(10,2),
    "created_at" timestamp DEFAULT now(),
    "description" text,
    "tags" ARRAY,
    "metadata" jsonb,
    "is_active" boolean DEFAULT true
);
CREATE VIEW "public"."active_products" AS
 SELECT products.name,
    products.price,
    products.description
   FROM products
  WHERE (products.is_active = true);;
CREATE VIEW "public"."recent_orders" AS
 SELECT o.id,
    p.name AS product_name,
    o.quantity,
    o.order_date,
    o.customer_email,
    o.status
   FROM (orders o
     JOIN products p ON ((o.product_id = p.id)))
  WHERE (o.order_date >= (now() - '7 days'::interval));;

--
-- Data for table "public"."orders"
--

COPY "public"."orders" FROM stdin;
1	1	2	2026-01-30 19:55:56.798725	alice@test.com	completed
2	2	1	2026-01-30 19:55:56.798725	bob@test.com	processing
3	3	1	2026-01-30 19:55:56.798725	carol@test.com	pending
4	4	3	2026-01-30 19:55:56.798725	david@test.com	completed
\.


--
-- Data for table "public"."products"
--

COPY "public"."products" FROM stdin;
1	Laptop Pro Max	2199.99	2026-01-30 19:55:56.798725	Ultimate performance laptop	{tech,mobile,work}	{"cpu": "M3 Pro", "ram": "32GB", "storage": "1TB SSD"}	t
2	Wireless Headphones	299.50	2026-01-30 19:55:56.798725	Premium noise-canceling headphones	{audio,wireless}	{"anc": true, "battery": "30h"}	t
3	Coffee Machine	89.99	2026-01-30 19:55:56.798725	Automatic espresso machine	{kitchen,coffee}	{"capacity": "1.5L", "pressure": "15 bar"}	t
4	Programming Book	59.99	2026-01-30 19:55:56.798725	Advanced Go Programming Techniques	{books,tech}	{"level": "advanced", "pages": 420}	t
\.


--
-- PostgreSQL database dump complete
--
